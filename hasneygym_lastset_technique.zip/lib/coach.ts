// Local storage key used to persist which user the coach is impersonating.
export const COACH_IMPERSONATE_KEY = 'coach:impersonateUserId';

// Local storage key used to persist which user's email the coach is impersonating (UI-only).
export const COACH_IMPERSONATE_EMAIL_KEY = 'coach:impersonateUserEmail';
