'use client';

import { Fragment, useEffect, useMemo, useRef, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase';
import { useCoach } from '@/hooks/useCoach';
import { cacheDel } from '@/lib/perfCache';

import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {Plus, Clock, Trash2, GripVertical, Info, Dumbbell, MoreVertical, RefreshCcw} from 'lucide-react';
type WorkoutSession = any;
type WorkoutExercise = any;
type WorkoutSet = any;

function formatClock(totalSeconds: number) {
  const s = Math.max(0, Math.floor(totalSeconds));
  const hh = Math.floor(s / 3600);
  const mm = Math.floor((s % 3600) / 60);
  const ss = s % 60;
  const pad = (n: number) => String(n).padStart(2, '0');
  return hh > 0 ? `${hh}:${pad(mm)}:${pad(ss)}` : `${mm}:${pad(ss)}`;
}

function clampInt(n: number, min: number, max: number) {
  if (!Number.isFinite(n)) return min;
  return Math.min(max, Math.max(min, Math.floor(n)));
}

function formatHMFromSeconds(totalSeconds: number | null | undefined) {
  const s = Math.max(0, Math.floor(Number(totalSeconds) || 0));
  const hh = Math.floor(s / 3600);
  const mm = Math.floor((s % 3600) / 60);
  return `${hh}:${String(mm).padStart(2, '0')}`;
}

function parseHM(input: string): number {
  const raw = (input || '').trim();
  if (!raw) return 0;
  // Accept: "H:MM" or "MM" (minutes). No seconds.
  // - "25"   => 25 minutes
  // - "1:30" => 1 hour 30 minutes
  if (/^\d+$/.test(raw)) return Math.max(0, parseInt(raw, 10)) * 60;
  const parts = raw.split(':').map((p) => p.trim());
  if (parts.length !== 2) return 0;
  const hh = parseInt(parts[0] || '0', 10);
  const mm = parseInt(parts[1] || '0', 10);
  if (!Number.isFinite(hh) || !Number.isFinite(mm)) return 0;
  return Math.max(0, Math.max(0, hh) * 3600 + clampInt(mm, 0, 59) * 60);
}

function isCardioWorkoutExercise(ex: any) {
  return ex?.exercises?.exercise_type === 'cardio' || ex?.exercises?.muscle_group === 'Cardio';
}



const TECHNIQUE_GUIDES: Record<
  string,
  { title: string; summary: string; steps: string[]; tips?: string[] }
> = {
  'Normal-Sets': {
    title: 'Normal Sets',
    summary: 'Standard straight sets with consistent rest and tempo.',
    steps: [
      'Choose a load you can control through the full range of motion.',
      'Perform your prescribed reps with consistent form.',
      'Rest the planned duration, then repeat for the next set.',
    ],
    tips: ['Stop 0–2 reps shy of failure for most sets unless your program says otherwise.'],
  },
  'Drop-Sets': {
    title: 'Drop Sets',
    summary: 'Reduce weight after reaching near-failure and continue with minimal rest.',
    steps: [
      'Perform a set to near-failure at your working weight.',
      'Immediately reduce the load by ~10–30% (no long rest).',
      'Continue for more reps; repeat 1–2 more drops if desired.',
    ],
    tips: ['Keep form strict—drop weight, not technique.'],
  },
  'Rest-Pause': {
    title: 'Rest-Pause',
    summary: 'Brief rests to extend a set beyond initial fatigue.',
    steps: [
      'Perform reps to near-failure.',
      'Rest 10–20 seconds.',
      'Do additional reps; repeat 1–3 mini-sets with the same weight.',
    ],
    tips: ['Great for machines/cables where setup is quick.'],
  },
  GVT: {
    title: 'GVT (German Volume Training)',
    summary: 'High-volume protocol typically 10x10 at a challenging but repeatable load.',
    steps: [
      'Pick a weight you can complete for 10 reps with good form (often ~60% 1RM).',
      'Perform 10 sets of 10 reps with consistent rest (60–90 seconds).',
      'Keep tempo controlled and stop if form breaks down.',
    ],
    tips: ['Track performance—small load increases go a long way.'],
  },
  'Myo-Reps': {
    title: 'Myo-Reps',
    summary: 'Activation set to near-failure followed by short-rest clusters.',
    steps: [
      'Do an activation set to near-failure (e.g., 12–20 reps).',
      'Rest 10–20 seconds.',
      'Perform mini-sets of 3–5 reps, resting 10–20 seconds between.',
      'Stop when rep quality drops or you miss the target mini-set reps.',
    ],
    tips: ['Use stable exercises (machines/cables) to keep clusters consistent.'],
  },
  'Super-Sets': {
    title: 'Super Sets',
    summary: 'Two exercises performed back-to-back with little to no rest.',
    steps: [
      'Perform exercise A for prescribed reps.',
      'Immediately perform exercise B for prescribed reps.',
      'Rest 60–120 seconds after the pair, then repeat.',
    ],
    tips: ['Pair opposing muscles (e.g., chest/back) or non-competing movements for best performance.'],
  },
  Failure: {
    title: 'Failure',
    summary: 'Perform reps until you cannot complete another rep with good form.',
    steps: [
      'Warm up properly and choose a safe exercise variation.',
      'Perform reps until you cannot complete the next rep with proper form.',
      'Stop the set as soon as technique breaks down.',
    ],
    tips: ['Use mostly on machines/cables and limit frequency to manage fatigue.'],
  },
};

// Techniques that should display a reminder label on the LAST set row.
const TECHNIQUE_LAST_SET_REMINDER = new Set(['Rest-Pause', 'Drop-Sets', 'Myo-Reps', 'Failure']);


export default function WorkoutPage() {
  const params = useParams();
  const router = useRouter();
  const { effectiveUserId } = useCoach();
  const sessionId = params.sessionId as string;

  const [session, setSession] = useState<WorkoutSession | null>(null);
  const [exercises, setExercises] = useState<WorkoutExercise[]>([]);
  const [sets, setSets] = useState<{ [exerciseId: string]: WorkoutSet[] }>({});

  const [prevSetsByExercise, setPrevSetsByExercise] = useState<Record<string, WorkoutSet[]>>({});

  // Prevent out-of-order async loads (multiple loadWorkout() calls can overlap
  // when effectiveUserId/sessionId changes). Without this, a slower, older load
  // can overwrite newer state and cause "flashing" and incorrect reps/weight.
  const loadSeqRef = useRef(0);

  // Add Exercise (session-only): allows adding extra exercises during a workout day
  const [showAddExercise, setShowAddExercise] = useState(false);
  const [selectedExerciseId, setSelectedExerciseId] = useState('');
  const [availableExercises, setAvailableExercises] = useState<any[]>([]);
  const [addingExercise, setAddingExercise] = useState(false);

// Exercise actions (HEVY-style 3-dot menu)
const [exerciseMenuOpen, setExerciseMenuOpen] = useState(false);
const [exerciseMenuExerciseId, setExerciseMenuExerciseId] = useState<string | null>(null);

const [showReplaceExercise, setShowReplaceExercise] = useState(false);
const [replaceExerciseId, setReplaceExerciseId] = useState('');

  // Cardio (time-based) draft input per workout_exercise_id
  const [cardioDraft, setCardioDraft] = useState<Record<string, string>>({});

  // Micro-interactions: track which set was just added/removed for subtle animations
  const [highlightSetId, setHighlightSetId] = useState<string | null>(null);
  const [removingSetIds, setRemovingSetIds] = useState<Set<string>>(() => new Set());



// Swipe-to-delete state (HEVY-style)
const [swipeOffsetBySetId, setSwipeOffsetBySetId] = useState<Record<string, number>>({});
const [swipeDraggingSetId, setSwipeDraggingSetId] = useState<string | null>(null);
const swipeRef = useRef<{ setId: string | null; startX: number; startY: number; startOffset: number; active: boolean }>({
  setId: null,
  startX: 0,
  startY: 0,
  startOffset: 0,
  active: false,
});

const closeAllSwipes = () => setSwipeOffsetBySetId({});

const onSetSwipeStart = (setId: string, e: any) => {
  if (sessionIsCompleted) return;
  const t = e.touches?.[0];
  if (!t) return;
  // close others
  setSwipeOffsetBySetId((prev) => {
    const cur = prev[setId] ?? 0;
    return cur !== 0 ? { [setId]: cur } : {};
  });
  swipeRef.current = {
    setId,
    startX: t.clientX,
    startY: t.clientY,
    startOffset: swipeOffsetBySetId[setId] ?? 0,
    active: false,
  };
  setSwipeDraggingSetId(setId);
};

const onSetSwipeMove = (setId: string, e: any) => {
  const t = e.touches?.[0];
  if (!t) return;
  const ref = swipeRef.current;
  if (ref.setId !== setId) return;

  const dx = t.clientX - ref.startX;
  const dy = t.clientY - ref.startY;

  // Activate only for horizontal swipes (avoid fighting vertical scroll)
  if (!ref.active) {
    if (Math.abs(dx) < 10) return;
    if (Math.abs(dx) <= Math.abs(dy) + 6) return;
    ref.active = true;
  }

  // Prevent page scroll while swiping horizontally.
  // On iOS, calling preventDefault on non-cancelable or passive events can cause
  // intermittent scroll jank/freezes.
  if (e?.cancelable) e.preventDefault?.();

  const raw = ref.startOffset + dx;
  const clamped = Math.max(-120, Math.min(0, raw));
  setSwipeOffsetBySetId((prev) => ({ ...prev, [setId]: clamped }));
};

const onSetSwipeEnd = (setId: string, _e: any) => {
  const off = swipeOffsetBySetId[setId] ?? 0;
  const shouldOpen = off < -70;
  setSwipeOffsetBySetId((prev) => ({ ...prev, [setId]: shouldOpen ? -120 : 0 }));
  setSwipeDraggingSetId(null);
  swipeRef.current = { setId: null, startX: 0, startY: 0, startOffset: 0, active: false };
};
  // Draft typed values: used only while editing; after blur it gets cleared.
  const [draft, setDraft] = useState<Record<string, Record<string, string>>>({});

  // Debounced background save for iOS/Safari: onBlur is not reliable when users
  // scroll, switch apps, or jump between exercises quickly.
  const draftSaveTimers = useRef<Record<string, any>>({});

  const scheduleDraftSave = (setId: string, field: 'weight' | 'reps', raw: string) => {
    const key = `${setId}:${field}`;
    if (draftSaveTimers.current[key]) clearTimeout(draftSaveTimers.current[key]);
    draftSaveTimers.current[key] = setTimeout(() => {
      const trimmed = String(raw ?? '').trim();
      const num = trimmed === '' ? 0 : Number(trimmed);
      // Save immediately so History and "Previous" stay correct even if blur never fires.
      saveSet(setId, field, Number.isFinite(num) ? num : 0);
    }, 250);
  };

  const flushDraftSaves = async () => {
    // Force-save any in-flight draft values so they don't get lost if we reload,
    // the user switches exercises, or Safari backgrounding interrupts blur.
    const pending: Array<PromiseLike<any>> = [];
    for (const setId of Object.keys(draft)) {
      const fields = draft[setId] || {};
      for (const field of Object.keys(fields)) {
        if (field !== 'weight' && field !== 'reps') continue;
        const raw = String(fields[field] ?? '').trim();
        const num = raw === '' ? 0 : Number(raw);
        pending.push(Promise.resolve(supabase.from('workout_sets').update({ [field]: Number.isFinite(num) ? num : 0 }).eq('id', setId)));
      }
    }
    if (pending.length > 0) {
      try {
        await Promise.all(pending);
      } catch (e) {
        // Non-fatal: UI remains and we can reload if needed.
        console.warn('flushDraftSaves failed', e);
      }
    }
  };

// Technique guide sheet (shows instructions for the CURRENT selected technique)
const [techniqueGuideOpen, setTechniqueGuideOpen] = useState(false);
const [techniqueGuideExerciseId, setTechniqueGuideExerciseId] = useState<string | null>(null);

// Set-technique (Normal-Sets / Rest-Pause, etc) picker for the active session.
const [setTechniqueOpen, setSetTechniqueOpen] = useState(false);
const [techniqueExerciseId, setTechniqueExerciseId] = useState<string | null>(null);

const SET_TECHNIQUES = ['Normal-Sets', 'Drop-Sets', 'Rest-Pause', 'GVT', 'Myo-Reps', 'Super-Sets', 'Failure'];

const openSetTechnique = (workoutExerciseId: string) => {
  setTechniqueExerciseId(workoutExerciseId);
  setSetTechniqueOpen(true);
};

const openTechniqueGuide = (workoutExerciseId: string) => {
  setTechniqueGuideExerciseId(workoutExerciseId);
  setTechniqueGuideOpen(true);
};

const applySetTechnique = async (newTechnique: string) => {
  const workoutExerciseId = techniqueExerciseId;
  if (!workoutExerciseId) return;

  // Find the row so we can (optionally) persist the selection back to the routine template.
  const row = exercises.find((e: any) => e.id === workoutExerciseId) as any;
  const originRoutineDayExerciseId = row?.routine_day_exercise_id as string | null | undefined;

  // Optimistic UI: update immediately.
  setExercises((prev: any[]) =>
    prev.map((e: any) => (e.id === workoutExerciseId ? { ...e, technique_tags: [newTechnique] } : e))
  );

  try {
		// NOTE: Supabase update builders are "thenable" but not typed as Promise.
		// Await them explicitly to satisfy TypeScript and keep behavior clear.
		const res1 = await supabase
			.from('workout_exercises')
			.update({ technique_tags: [newTechnique] })
			.eq('id', workoutExerciseId);
		if (res1?.error) throw res1.error;

		// If the workout was started from a routine day and this exercise was seeded from a specific template row,
		// persist the selection so future workouts inherit it.
		if (originRoutineDayExerciseId) {
			const res2 = await supabase
				.from('routine_day_exercises')
				.update({ technique_tags: [newTechnique] })
				.eq('id', originRoutineDayExerciseId);
			if (res2?.error) throw res2.error;
		}

		// Smart default: remember the last selected technique for this exercise (used when adding the exercise again).
		if (effectiveUserId && row?.exercise_id) {
			const res3 = await supabase
				.from('user_exercise_preferences')
				.upsert(
					{
						user_id: effectiveUserId,
						exercise_id: row.exercise_id,
						technique: newTechnique,
						updated_at: new Date().toISOString(),
					},
					{ onConflict: 'user_id,exercise_id' }
				);
			if (res3?.error) throw res3.error;
		}

  } catch (e: any) {
    console.error(e);
    alert(e?.message || 'Failed to update technique.');
    // Re-sync from server in case optimistic update diverged.
    await loadWorkout();
  } finally {
    setSetTechniqueOpen(false);
    setTechniqueExerciseId(null);
  }
};

  // Session clock
  const [elapsedSeconds, setElapsedSeconds] = useState(0);

  // Rest timer
  const [restSecondsRemaining, setRestSecondsRemaining] = useState<number | null>(null);
  const [restExerciseId, setRestExerciseId] = useState<string | null>(null);
  const restIntervalRef = useRef<number | null>(null);
  const beepedRef = useRef(false);

  // Input focus map for fast logging (mobile + keyboard)
  const inputRefs = useRef<Map<string, HTMLInputElement>>(new Map());
  const [pendingFocusKey, setPendingFocusKey] = useState<string | null>(null);

  // Session-only exercise reorder (mobile-friendly pointer drag)
  const exerciseNodeRefs = useRef<Map<string, HTMLDivElement>>(new Map());
  const [draggingExerciseId, setDraggingExerciseId] = useState<string | null>(null);
  const dragPointerYRef = useRef<number>(0);
  const dragStartYRef = useRef<number>(0);
  const dragStartIndexRef = useRef<number>(-1);
  const dragOffsetYRef = useRef<number>(0);
  const [dragOverIndex, setDragOverIndex] = useState<number>(-1);
  const [dragTranslateY, setDragTranslateY] = useState<number>(0);
  const dragRafRef = useRef<number | null>(null);
  const [isPersistingOrder, setIsPersistingOrder] = useState(false);
  const exercisesRef = useRef<WorkoutExercise[]>([]);

  useEffect(() => {
    exercisesRef.current = exercises;
  }, [exercises]);

  const arrayMove = <T,>(arr: T[], from: number, to: number) => {
    const next = arr.slice();
    const [item] = next.splice(from, 1);
    next.splice(to, 0, item);
    return next;
  };

  const persistExerciseOrder = async (ordered: WorkoutExercise[]) => {
    // Keep order stable for this session only via workout_exercises.order_index.
    // Avoid uniqueness conflicts by writing a temporary index space first.
    if (isPersistingOrder) return;
    setIsPersistingOrder(true);
    try {
      for (let i = 0; i < ordered.length; i++) {
        const id = (ordered[i] as any)?.id;
        if (!id) continue;
        await supabase.from('workout_exercises').update({ order_index: 1000 + i }).eq('id', id);
      }
      for (let i = 0; i < ordered.length; i++) {
        const id = (ordered[i] as any)?.id;
        if (!id) continue;
        await supabase.from('workout_exercises').update({ order_index: i }).eq('id', id);
      }
    } finally {
      setIsPersistingOrder(false);
    }
  };

  const startExerciseDrag = (exerciseId: string, e: React.PointerEvent) => {
    if (session?.ended_at) return; // no edits once completed
    const idx = exercises.findIndex((x: any) => x.id === exerciseId);
    if (idx < 0) return;

    const node = exerciseNodeRefs.current.get(exerciseId);
    if (!node) return;

    try {
      (e.currentTarget as any)?.setPointerCapture?.(e.pointerId);
    } catch {}

    e.preventDefault();
    e.stopPropagation();

    const rect = node.getBoundingClientRect();
    dragStartYRef.current = e.clientY;
    dragPointerYRef.current = e.clientY;
    dragStartIndexRef.current = idx;
    dragOffsetYRef.current = e.clientY - rect.top;
    setDraggingExerciseId(exerciseId);
    setDragOverIndex(idx);
    vibrate(8);
  };

  const stopExerciseDrag = async () => {
    setDraggingExerciseId(null);
    setDragOverIndex(-1);
    dragStartIndexRef.current = -1;
    setDragTranslateY(0);
    if (dragRafRef.current != null) {
      cancelAnimationFrame(dragRafRef.current);
      dragRafRef.current = null;
    }
    // Persist the current in-memory order for this session only.
    try {
      await persistExerciseOrder(exercisesRef.current);
    } catch (err) {
      console.error(err);
      await loadWorkout();
    }
  };

  useEffect(() => {
    if (!draggingExerciseId) return;

    const onMove = (ev: PointerEvent) => {
      dragPointerYRef.current = ev.clientY;

      // Auto-scroll while dragging near viewport edges (mobile-friendly, HEVY-like)
      const edge = 80;
      const y = ev.clientY;
      const vh = window.innerHeight;
      if (y < edge) {
        const strength = (edge - y) / edge;
        window.scrollBy({ top: -Math.round(18 * strength), left: 0, behavior: 'auto' });
      } else if (y > vh - edge) {
        const strength = (y - (vh - edge)) / edge;
        window.scrollBy({ top: Math.round(18 * strength), left: 0, behavior: 'auto' });
      }

      // Follow the finger (throttled via rAF to keep it smooth on mobile)
      if (dragRafRef.current == null) {
        dragRafRef.current = requestAnimationFrame(() => {
          dragRafRef.current = null;
          setDragTranslateY(dragPointerYRef.current - dragStartYRef.current);
        });
      }
      // Determine which index we're currently over by comparing to card midpoints.
      const entries = exercises
        .map((ex: any, i: number) => {
          const n = exerciseNodeRefs.current.get(ex.id);
          if (!n) return null;
          const r = n.getBoundingClientRect();
          return { id: ex.id, i, top: r.top, mid: r.top + r.height / 2, bottom: r.bottom };
        })
        .filter(Boolean) as { id: string; i: number; top: number; mid: number; bottom: number }[];
      if (entries.length === 0) return;

      // Use the pointer position, not the element rect, for a more natural mobile feel.
      let over = dragOverIndex;
      for (const it of entries) {
        if (y < it.mid) {
          over = it.i;
          break;
        }
        over = it.i;
      }
      if (over !== dragOverIndex) {
        // Reset the visual translate baseline when the list reorders, reducing perceived "jump".
        dragStartYRef.current = ev.clientY;
        setDragTranslateY(0);
        // Live reorder for HEVY-like feel
        setExercises((prev) => {
          const from = dragStartIndexRef.current;
          if (from < 0 || from >= prev.length) return prev;
          const to = over;
          if (to < 0 || to >= prev.length) return prev;
          if (from === to) return prev;
          const next = arrayMove(prev, from, to);
          dragStartIndexRef.current = to;
          return next;
        });
        setDragOverIndex(over);
        vibrate(4);
      }
      ev.preventDefault();
    };

    const onUp = () => {
      stopExerciseDrag();
    };

    window.addEventListener('pointermove', onMove, { passive: false });
    window.addEventListener('pointerup', onUp, { passive: true });
    window.addEventListener('pointercancel', onUp, { passive: true });
    return () => {
      window.removeEventListener('pointermove', onMove as any);
      window.removeEventListener('pointerup', onUp as any);
      window.removeEventListener('pointercancel', onUp as any);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [draggingExerciseId, exercises, dragOverIndex, session?.ended_at]);

  // Session-only reordering + removal should not be allowed once a session is completed.
  const sessionIsCompleted = Boolean(session?.ended_at);

  const removeExerciseFromSession = async (workoutExerciseId: string) => {
    if (sessionIsCompleted) return;
    if (!confirm('Remove this exercise from this workout session?')) return;

    try {
      // Delete the workout_exercises row; workout_sets cascade delete via FK.
      await supabase.from('workout_exercises').delete().eq('id', workoutExerciseId);

      // Reindex remaining order_index values to keep ordering constraints clean.
      const remaining = exercises.filter((x: any) => x.id !== workoutExerciseId);
      await persistExerciseOrder(remaining);
      await loadWorkout();
    } catch (err) {
      console.error(err);
      alert('Failed to remove exercise from session.');
      await loadWorkout();
    }
  };


const openExerciseMenu = (workoutExerciseId: string) => {
  setExerciseMenuExerciseId(workoutExerciseId);
  setExerciseMenuOpen(true);
};

const beginReplaceExercise = (workoutExerciseId: string) => {
  setExerciseMenuExerciseId(workoutExerciseId);
  setReplaceExerciseId('');
  setShowReplaceExercise(true);
  setExerciseMenuOpen(false);
};

const applyReplaceExercise = async () => {
  const workoutExerciseId = exerciseMenuExerciseId;
  const newExerciseId = replaceExerciseId;
  if (!workoutExerciseId || !newExerciseId) return;

  try {
    // Update the workout exercise to point at the new exercise
    const { error: upErr } = await supabase
      .from('workout_exercises')
      .update({ exercise_id: newExerciseId })
      .eq('id', workoutExerciseId);
    if (upErr) throw upErr;

    // Fetch default reps for the new exercise (best-effort)
    const { data: exMeta } = await supabase
      .from('exercises')
      .select('default_set_scheme')
      .eq('id', newExerciseId)
      .maybeSingle();

    const scheme = (exMeta as any)?.default_set_scheme ?? null;
    const schemeReps = scheme && typeof scheme === 'object' ? Number((scheme as any).reps) : NaN;
    const defaultReps = Number.isFinite(schemeReps) ? Math.max(0, Math.floor(schemeReps)) : 0;

    // Keep the current number of sets, but reset them (HEVY-like)
    const existing = sets[workoutExerciseId] || [];
    if (existing.length > 0) {
      const updates = existing.map((s: any) => ({
        id: s.id,
        reps: defaultReps,
        weight: 0,
        is_completed: false,
      }));
      await supabase.from('workout_sets').upsert(updates, { onConflict: 'id' });
    } else {
      // If there are no sets, create at least 1
      await supabase.from('workout_sets').insert([
        { workout_exercise_id: workoutExerciseId, set_index: 0, reps: defaultReps, weight: 0, rpe: null, is_completed: false },
      ]);
    }

    setShowReplaceExercise(false);
    await loadWorkout();
  } catch (e: any) {
    console.error(e);
    alert(e?.message || 'Failed to replace exercise.');
    await loadWorkout();
  }
};
  const focusByKey = (key: string) => {
    const el = inputRefs.current.get(key);
    if (el) {
      el.focus();
      // select after focus for quick overwrite
      requestAnimationFrame(() => el.select?.());
      return true;
    }
    return false;
  };

  const vibrate = (pattern: number | number[] = 10) => {
    try {
      // haptics on supported mobile devices (non-blocking)
      if (typeof navigator !== 'undefined' && 'vibrate' in navigator) (navigator as any).vibrate(pattern);
    } catch {}
  };

  const playBeep = () => {
    // Loud "boxing bell" style alert using Web Audio API (no external assets).
    // Uses a few harmonics + longer decay, plus a second strike.
    try {
      const AudioCtx = (window as any).AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;

      const ctx = new AudioCtx();

      // Smooth out peaks to avoid distortion while staying loud.
      const compressor = ctx.createDynamicsCompressor();
      compressor.threshold.setValueAtTime(-18, ctx.currentTime);
      compressor.knee.setValueAtTime(18, ctx.currentTime);
      compressor.ratio.setValueAtTime(6, ctx.currentTime);
      compressor.attack.setValueAtTime(0.003, ctx.currentTime);
      compressor.release.setValueAtTime(0.15, ctx.currentTime);

      const master = ctx.createGain();
      master.gain.setValueAtTime(0.9, ctx.currentTime);

      master.connect(compressor);
      compressor.connect(ctx.destination);

      const strike = (t0: number) => {
        const gain = ctx.createGain();
        gain.gain.setValueAtTime(0.0001, t0);
        // Fast attack, long decay (bell-like)
        gain.gain.exponentialRampToValueAtTime(0.95, t0 + 0.008);
        gain.gain.exponentialRampToValueAtTime(0.08, t0 + 0.35);
        gain.gain.exponentialRampToValueAtTime(0.0001, t0 + 1.2);
        gain.connect(master);

        const freqs = [740, 1110, 1480]; // bell-ish partials
        const types: OscillatorType[] = ['triangle', 'sine', 'square'];
        const oscs = freqs.map((f, i) => {
          const osc = ctx.createOscillator();
          osc.type = types[i];
          osc.frequency.setValueAtTime(f, t0);
          // slight detune for richness
          osc.detune.setValueAtTime((i - 1) * 8, t0);
          osc.connect(gain);
          osc.start(t0);
          osc.stop(t0 + 1.25);
          return osc;
        });

        // Cleanup when the last oscillator ends
        oscs[oscs.length - 1].onended = () => {
          try {
            gain.disconnect();
          } catch {}
        };
      };

      const now = ctx.currentTime + 0.01;
      strike(now);
      strike(now + 0.35);

      // Close audio context after it finishes
      setTimeout(() => {
        try {
          ctx.close();
        } catch {}
      }, 1800);
    } catch {}
  };


  // End/Discard states
  const [ending, setEnding] = useState(false);
  const [discarding, setDiscarding] = useState(false);

  const startAtMs = useMemo(() => {
    const started = session?.started_at ? new Date(session.started_at).getTime() : NaN;
    return Number.isFinite(started) ? started : Date.now();
  }, [session?.started_at]);

  const setDraftValue = (setId: string, field: string, value: string) => {
    setDraft((prev) => ({
      ...prev,
      [setId]: { ...(prev[setId] || {}), [field]: value },
    }));
  };

  const clearDraftField = (setId: string, field: string) => {
    setDraft((prev) => {
      const next = { ...prev };
      if (!next[setId]) return prev;
      const inner = { ...next[setId] };
      delete inner[field];
      next[setId] = inner;
      return next;
    });
  };

  // ✅ This is the key fix:
  // - If user is typing (draft exists), show draft.
  // - Otherwise show the saved value from state (sets) — but keep it blank if 0.
  const getDisplayValue = (setId: string, field: 'reps' | 'weight', savedValue: any) => {
    const v = draft[setId]?.[field];
    if (v !== undefined) return v;
    const n = Number(savedValue ?? 0);
    if (!Number.isFinite(n) || n === 0) return '';
    return String(n);
  };

  const getDraftRaw = (setId: string, field: 'reps' | 'weight') => {
    const v = draft[setId]?.[field];
    return v !== undefined ? v : '';
  };

  const stopRestTimer = () => {
    setRestSecondsRemaining(null);
    setRestExerciseId(null);
    if (restIntervalRef.current) {
      window.clearInterval(restIntervalRef.current);
      restIntervalRef.current = null;
    }
  };

  const startRestTimer = (exerciseId: string, seconds: number) => {
    const dur = clampInt(seconds, 5, 600);
    beepedRef.current = false;
    setRestExerciseId(exerciseId);
    setRestSecondsRemaining(dur);

    if (restIntervalRef.current) {
      window.clearInterval(restIntervalRef.current);
      restIntervalRef.current = null;
    }

    restIntervalRef.current = window.setInterval(() => {
      setRestSecondsRemaining((prev) => {
        if (prev === null) return null;
        const next = prev - 1;
        if (next <= 0) {
          if (restIntervalRef.current) {
            window.clearInterval(restIntervalRef.current);
            restIntervalRef.current = null;
          }
          if (!beepedRef.current) {
            beepedRef.current = true;
            playBeep();
            vibrate([60, 40, 60]);
          }
          return null;
        }
        return next;
      });
    }, 1000);
  };

  useEffect(() => {
    const tick = () => {
      const now = Date.now();
      setElapsedSeconds(Math.max(0, Math.floor((now - startAtMs) / 1000)));
    };
    tick();
    const id = window.setInterval(tick, 1000);
    return () => window.clearInterval(id);
  }, [startAtMs]);

  useEffect(() => {
    return () => {
      if (restIntervalRef.current) {
        window.clearInterval(restIntervalRef.current);
        restIntervalRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    loadWorkout();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sessionId, effectiveUserId]);

  // iOS/Safari reliability: persist edits when the page is backgrounded or
  // when the browser freezes JS timers while scrolling.
  useEffect(() => {
    const onVis = () => {
      if (document.visibilityState === 'hidden') {
        flushDraftSaves();
      }
    };
    const onPageHide = () => {
      flushDraftSaves();
    };
    document.addEventListener('visibilitychange', onVis);
    window.addEventListener('pagehide', onPageHide);
    window.addEventListener('beforeunload', onPageHide);
    return () => {
      document.removeEventListener('visibilitychange', onVis);
      window.removeEventListener('pagehide', onPageHide);
      window.removeEventListener('beforeunload', onPageHide);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Load exercise list lazily for the session-only "Add Exercise" flow
  useEffect(() => {
    if (!showAddExercise && !showReplaceExercise) return;
    let cancelled = false;

    const load = async () => {
      if (availableExercises.length > 0) return;

      const { data, error } = await supabase
        .from('exercises')
        .select('id, name, muscle_group, exercise_type')
        .order('name');

      if (!cancelled && !error && data) {
        setAvailableExercises(data);
      }
    };

    load();
    return () => {
      cancelled = true;
    };
  }, [showAddExercise, showReplaceExercise, availableExercises.length]);

  // Apply pending focus after async updates (e.g., adding a set triggers reload)
  useEffect(() => {
    if (!pendingFocusKey) return;
    // try twice: immediately and next frame (DOM may still be updating)
    if (focusByKey(pendingFocusKey)) {
      setPendingFocusKey(null);
      return;
    }
    const id = requestAnimationFrame(() => {
      if (focusByKey(pendingFocusKey)) setPendingFocusKey(null);
    });
    return () => cancelAnimationFrame(id);
  }, [pendingFocusKey, sets]);

  const loadWorkout = async () => {
    const loadId = ++loadSeqRef.current;
    // Make sure any in-flight edits are persisted before we refresh data.
    // This prevents iOS Safari from losing edits when switching exercises or scrolling.
    await flushDraftSaves();
    if (loadId !== loadSeqRef.current) return;

    const { data: sessionData } = await supabase
      .from('workout_sessions')
      .select('*, routines(name), routine_days(name)')
      .eq('id', sessionId)
      .single();

    if (!sessionData) return;

    if (loadId !== loadSeqRef.current) return;

    setSession(sessionData);

    const { data: exData } = await supabase
      .from('workout_exercises')
      .select('*, exercises(*)')
      .eq('workout_session_id', sessionId)
      .order('order_index');

    if (!exData) return;

    if (loadId !== loadSeqRef.current) return;

    setExercises(exData);

    const exIds = exData.map((e: any) => e.id);
    const { data: allSets } = await supabase
      .from('workout_sets')
      .select('*')
      .in('workout_exercise_id', exIds)
      .order('set_index');

    if (loadId !== loadSeqRef.current) return;

    const map: { [exerciseId: string]: WorkoutSet[] } = {};
    for (const ex of exData) map[ex.id] = [];
    for (const s of allSets || []) {
      map[s.workout_exercise_id] = map[s.workout_exercise_id] || [];
      map[s.workout_exercise_id].push(s);
    }
    // Fetch previous sets first, then patch the initial set map BEFORE rendering.
    // This prevents the "flash" where default reps appear briefly before being replaced
    // by previous-session reps.
    const prevMap = await loadPreviousSetsForExercises(exData, sessionData.started_at, sessionData.user_id);
    if (loadId !== loadSeqRef.current) return;

    const { patched, updates } = prefillRepsFromPrevious(exData, map, prevMap);

    setPrevSetsByExercise(prevMap);

    // Overlay any draft edits (user may be mid-edit while we reload for add/reorder/etc.)
    const patchedWithDrafts: { [exerciseId: string]: WorkoutSet[] } = {};
    for (const weId of Object.keys(patched)) {
      patchedWithDrafts[weId] = (patched[weId] || []).map((s: any) => {
        const d = draft[s.id];
        if (!d) return s;
        const next = { ...s };
        if (typeof d.weight === 'string') {
          const n = d.weight.trim() === '' ? 0 : Number(d.weight);
          next.weight = Number.isFinite(n) ? n : next.weight;
        }
        if (typeof d.reps === 'string') {
          const n = d.reps.trim() === '' ? 0 : Number(d.reps);
          next.reps = Number.isFinite(n) ? n : next.reps;
        }
        return next;
      });
    }

    setSets(patchedWithDrafts);

    // Persist the reps prefill in the background (no second setSets call).
    if (loadId !== loadSeqRef.current) return;
    if (updates.length > 0) {
      const { error: upErr } = await supabase.from('workout_sets').upsert(updates, { onConflict: 'id' });
      if (upErr) {
        console.error('Prefill upsert failed:', upErr);
        // Non-fatal. UI is already correct; we just won't persist the prefill.
      }
    }
  };

  const addExerciseToSession = async () => {
    if (!selectedExerciseId) {
      alert('Select an exercise first.');
      return;
    }
    if (addingExercise) return;

    try {
      setAddingExercise(true);

      // determine order index (append to end)
      const nextOrder = exercises.length;

      // Pull exercise metadata so we can branch:
      // - Strength = set-based
      // - Cardio = time-based (no workout_sets)
      const { data: exMeta } = await supabase
        .from('exercises')
        .select('default_set_scheme, muscle_group, exercise_type')
        .eq('id', selectedExerciseId)
        .maybeSingle();

      const isCardio =
        (exMeta as any)?.exercise_type === 'cardio' || (exMeta as any)?.muscle_group === 'Cardio';

      const scheme = (exMeta as any)?.default_set_scheme ?? null;
      const schemeSets = scheme && typeof scheme === 'object' ? Number((scheme as any).sets) : NaN;
      const schemeReps = scheme && typeof scheme === 'object' ? Number((scheme as any).reps) : NaN;

      const setsCount = isCardio ? 0 : Number.isFinite(schemeSets) ? Math.max(1, Math.floor(schemeSets)) : 1;
      const defaultReps = isCardio ? 0 : Number.isFinite(schemeReps) ? Math.max(0, Math.floor(schemeReps)) : 0;

      // Smart default: use the last technique the user chose for this exercise (across sessions).
      let defaultTechnique = 'Normal-Sets';
      if (effectiveUserId) {
        const { data: prefRow } = await supabase
          .from('user_exercise_preferences')
          .select('technique')
          .eq('user_id', effectiveUserId)
          .eq('exercise_id', selectedExerciseId)
          .maybeSingle();
        if (prefRow?.technique) defaultTechnique = String(prefRow.technique);
      }


      const { data: newWorkoutExercise, error: weErr } = await supabase
        .from('workout_exercises')
        .insert({
          workout_session_id: sessionId,
          exercise_id: selectedExerciseId,
          order_index: nextOrder,
          routine_day_exercise_id: null,
          technique_tags: [defaultTechnique],
          // Cardio stores time on the workout_exercises row.
          duration_seconds: 0,
        })
        .select('id')
        .single();

      if (weErr) throw weErr;

      const workoutExerciseId = (newWorkoutExercise as any)?.id as string | undefined;
      if (!workoutExerciseId) throw new Error('Failed to create workout exercise.');

      if (!isCardio) {
        const setsToInsert = Array.from({ length: setsCount }).map((_, i) => ({
          workout_exercise_id: workoutExerciseId,
          set_index: i,
          reps: defaultReps,
          weight: 0,
          rpe: null,
          is_completed: false,
        }));

        const { error: wsErr } = await supabase.from('workout_sets').insert(setsToInsert);
        if (wsErr) throw wsErr;
      }

      // Reset UI and reload workout (so it appears immediately and is logged to history via session tables)
      setSelectedExerciseId('');
      setShowAddExercise(false);
      await loadWorkout();
    } catch (e: any) {
      console.error(e);
      alert(e?.message || 'Failed to add exercise.');
    } finally {
      setAddingExercise(false);
    }
  };

  const loadPreviousSetsForExercises = async (
    exData: WorkoutExercise[],
    startedAt: string,
    userId: string
  ): Promise<Record<string, WorkoutSet[]>> => {
    // Performance + correctness:
    // Previous data is based on *exercise_id* (not routine), and should always pull
    // from the most recent prior session where that exercise was performed.
    // The old implementation queried per-exercise/per-session (very slow on iOS).
    // This implementation does it in a small number of batched queries.

    const currentByWorkoutExerciseId: Array<{ workoutExerciseId: string; exerciseId: string | null }> = exData.map((ex) => ({
      workoutExerciseId: ex.id,
      exerciseId: ex.exercise_id ?? null,
    }));

    const exerciseIds = Array.from(
      new Set(currentByWorkoutExerciseId.map((x) => x.exerciseId).filter(Boolean) as string[])
    );

    const out: Record<string, WorkoutSet[]> = {};
    for (const x of currentByWorkoutExerciseId) out[x.workoutExerciseId] = [];
    if (exerciseIds.length === 0) return out;

    // 1) Load recent previous sessions once.
    const { data: prevSessions, error: sessErr } = await supabase
      .from('workout_sessions')
      .select('id, started_at')
      .eq('user_id', userId)
      .lt('started_at', startedAt)
      .order('started_at', { ascending: false })
      .limit(50);
    if (sessErr) {
      console.warn('Previous sessions load failed', sessErr);
      return out;
    }
    if (!prevSessions || prevSessions.length === 0) return out;

    const prevSessionIds = prevSessions.map((s: any) => s.id);
    const sessionRank: Record<string, number> = {};
    prevSessionIds.forEach((id: string, idx: number) => (sessionRank[id] = idx));

    // 2) Load all matching prior workout_exercises in one query.
    const { data: prevWEs, error: weErr } = await supabase
      .from('workout_exercises')
      .select('id, exercise_id, workout_session_id')
      .in('workout_session_id', prevSessionIds)
      .in('exercise_id', exerciseIds);
    if (weErr) {
      console.warn('Previous exercises load failed', weErr);
      return out;
    }
    if (!prevWEs || prevWEs.length === 0) return out;

    // For each exercise_id, pick the most recent session (lowest rank).
    const bestPrevByExerciseId: Record<string, { weId: string; rank: number }> = {};
    for (const row of prevWEs as any[]) {
      const exId = row.exercise_id as string;
      const sessId = row.workout_session_id as string;
      const r = sessionRank[sessId] ?? 999999;
      const cur = bestPrevByExerciseId[exId];
      if (!cur || r < cur.rank) bestPrevByExerciseId[exId] = { weId: row.id as string, rank: r };
    }

    const prevWorkoutExerciseIds = Array.from(new Set(Object.values(bestPrevByExerciseId).map((x) => x.weId)));
    if (prevWorkoutExerciseIds.length === 0) return out;

    // 3) Load all sets for those previous workout_exercise ids in one query.
    const { data: prevSets, error: setsErr } = await supabase
      .from('workout_sets')
      .select('*')
      .in('workout_exercise_id', prevWorkoutExerciseIds)
      .order('set_index');
    if (setsErr) {
      console.warn('Previous sets load failed', setsErr);
      return out;
    }

    const prevSetsByWorkoutExerciseId: Record<string, WorkoutSet[]> = {};
    for (const s of (prevSets || []) as any[]) {
      const weId = s.workout_exercise_id as string;
      if (!prevSetsByWorkoutExerciseId[weId]) prevSetsByWorkoutExerciseId[weId] = [];
      prevSetsByWorkoutExerciseId[weId].push(s as any);
    }

    // Map previous sets back to the CURRENT workout_exercise ids.
    for (const cur of currentByWorkoutExerciseId) {
      const exId = cur.exerciseId;
      if (!exId) continue;
      const best = bestPrevByExerciseId[exId];
      if (!best) continue;
      out[cur.workoutExerciseId] = prevSetsByWorkoutExerciseId[best.weId] || [];
    }

    return out;
  };

  const prefillRepsFromPrevious = (
    exData: WorkoutExercise[],
    currentSetMap: { [exerciseId: string]: WorkoutSet[] },
    prevMap: Record<string, WorkoutSet[]>
  ): { patched: { [exerciseId: string]: WorkoutSet[] }; updates: Array<{ id: string; reps: number }> } => {
    // IMPORTANT:
    // We patch the initial set map BEFORE rendering (in loadWorkout) to avoid "flashing"
    // between default reps and previous reps on mobile.
    const updates: Array<{ id: string; reps: number }> = [];
    const patched: { [exerciseId: string]: WorkoutSet[] } = { ...currentSetMap };

    for (const ex of exData as any[]) {
      const weId = ex?.id as string;
      if (!weId) continue;

      const curSets = (currentSetMap?.[weId] || []) as any[];
      const prevSets = (prevMap?.[weId] || []) as any[];

      const schemeRepsRaw = ex?.exercises?.default_set_scheme?.reps;
      const schemeRepsNum = Number(schemeRepsRaw);
      const defaultReps = Number.isFinite(schemeRepsNum) ? Math.max(0, Math.floor(schemeRepsNum)) : null;
      if (defaultReps === null) continue;

      const nextList = curSets.map((s) => ({ ...s }));

      for (let i = 0; i < nextList.length; i++) {
        const cur = nextList[i];
        const prev = prevSets[i];
        const prevReps = prev?.reps;
        if (cur?.is_completed) continue;
        if (!Number.isFinite(Number(prevReps))) continue;

        const curRepsNum = Number(cur?.reps);
        const prevRepsNum = Number(prevReps);

        if (Number.isFinite(curRepsNum) && curRepsNum === defaultReps && prevRepsNum !== defaultReps) {
          updates.push({ id: cur.id, reps: prevRepsNum });
          cur.reps = prevRepsNum;
        }
      }

      patched[weId] = nextList as any;
    }

    return { patched, updates };
  };

  const saveSet = async (setId: string, field: string, value: any) => {
    // optimistic update so the value stays visible immediately
    setSets((prev) => {
      const next: { [exerciseId: string]: WorkoutSet[] } = {};
      for (const exId of Object.keys(prev)) {
        next[exId] = prev[exId].map((s: any) => (s.id === setId ? { ...s, [field]: value } : s));
      }
      return next;
    });

    const { error } = await supabase.from('workout_sets').update({ [field]: value }).eq('id', setId);

    if (error) {
      console.error('Save failed:', error);
      loadWorkout();
    }
  };

  const getExerciseRestSeconds = (ex: any): number => {
  // Rest time is set per exercise; default is 60 seconds.
  const v = ex?.exercises?.rest_seconds ?? ex?.exercises?.default_set_scheme?.restSeconds;
  const n = Number(v);
  return Number.isFinite(n) && n > 0 ? Math.floor(n) : 60;
};

  const handleToggleCompleted = async (workoutExerciseRow: any, setRow: any) => {
    const willComplete = !setRow.is_completed;
    await saveSet(setRow.id, 'is_completed', willComplete);
    if (willComplete) startRestTimer(workoutExerciseRow.id, getExerciseRestSeconds(workoutExerciseRow));
  };

  // Guardrail: only allow ending/saving a workout when all sets are completed
  // and required fields are filled out.
  const getWorkoutValidationError = (): string | null => {
    for (const ex of exercises) {
      const exName = ex?.exercises?.name || ex?.name || 'Exercise';
      const cardio = isCardioWorkoutExercise(ex);

      if (cardio) {
        const secs = Number((ex as any)?.duration_seconds || 0);
        if (!Number.isFinite(secs) || secs <= 0) {
          return `Please complete your workout before finishing.\n\n${exName} — cardio duration must be greater than 0.`;
        }
        continue;
      }
      const exSets = sets[ex.id] || [];

      if (exSets.length === 0) {
        return `Please complete your workout before finishing.\n\nMissing sets for: ${exName}`;
      }

      for (let i = 0; i < exSets.length; i++) {
        const s: any = exSets[i];
        const setLabel = `Set ${i + 1}`;

        // Require completion toggle.
        if (!s?.is_completed) {
          return `Please complete all sets before finishing.\n\n${exName} — ${setLabel} is not checked.`;
        }

        // Require reps > 0
        const reps = Number(s?.reps);
        if (!Number.isFinite(reps) || reps <= 0) {
          return `Please fill out all fields before finishing.\n\n${exName} — ${setLabel} has missing reps.`;
        }

        // Require a numeric weight (0 is allowed for bodyweight)
        const weight = Number(s?.weight);
        if (!Number.isFinite(weight) || weight < 0) {
          return `Please fill out all fields before finishing.\n\n${exName} — ${setLabel} has missing weight.`;
        }
      }
    }

    return null;
  };

  const endWorkout = async () => {
    const ok = window.confirm('End workout? This will save it to History.');
    if (!ok) return;

    try {
      setEnding(true);
      // Force-save any pending input values (critical for iOS/Safari).
      await flushDraftSaves();
      await supabase.from('workout_sessions').update({ ended_at: new Date().toISOString() }).eq('id', sessionId);

      // Ensure History updates immediately (it uses a short-lived local cache).
      const uid = effectiveUserId || (session as any)?.user_id;
      if (uid) cacheDel(`history:sessions:${uid}:v1`);

      router.push('/history');
    } finally {
      setEnding(false);
    }
  };

  const discardWorkout = async () => {
    const ok = window.confirm('Discard workout? This will permanently delete this session and all sets.');
    if (!ok) return;

    try {
      setDiscarding(true);

      const { data: exRows, error: exErr } = await supabase
        .from('workout_exercises')
        .select('id')
        .eq('workout_session_id', sessionId);
      if (exErr) throw exErr;
      const exIds = (exRows || []).map((r: any) => r.id);

      if (exIds.length > 0) {
        const { error: setsErr } = await supabase
          .from('workout_sets')
          .delete()
          .in('workout_exercise_id', exIds);
        if (setsErr) throw setsErr;
      }

      const { error: exDelErr } = await supabase
        .from('workout_exercises')
        .delete()
        .eq('workout_session_id', sessionId);
      if (exDelErr) throw exDelErr;

      const { error: sessDelErr } = await supabase
        .from('workout_sessions')
        .delete()
        .eq('id', sessionId);
      if (sessDelErr) throw sessDelErr;

      // Verify it actually deleted (prevents ghost/empty history entries).
      const { data: stillThere, error: checkErr } = await supabase
        .from('workout_sessions')
        .select('id')
        .eq('id', sessionId)
        .maybeSingle();
      if (checkErr) throw checkErr;

      if (stillThere?.id) {
        window.alert(
          'Discard did not fully complete, so this workout may still appear in History.\n\n' +
            'Go to History and delete the session there (trash icon) to remove it.'
        );
        return;
      }

      // Ensure History doesn't temporarily show the discarded empty session.
      const uid = effectiveUserId || (session as any)?.user_id;
      if (uid) cacheDel(`history:sessions:${uid}:v1`);

      router.push('/workout/start');
    } catch (err: any) {
      console.error('Discard workout failed:', err);
      window.alert(err?.message || 'Failed to discard workout. Please try again.');
    } finally {
      setDiscarding(false);
    }
  };

  const addSet = async (exerciseId: string) => {
    const currentSets = sets[exerciseId] || [];
    const lastSet = currentSets[currentSets.length - 1];

    const { data, error } = await supabase
      .from('workout_sets')
      .insert({
        workout_exercise_id: exerciseId,
        set_index: currentSets.length,
        reps: lastSet?.reps || 0,
        weight: lastSet?.weight || 0,
        rpe: null,
      })
      .select()
      .single();

    if (error) {
      console.error('Add set failed:', error);
      alert(error.message || 'Failed to add set.');
      return;
    }

    if (data) {
      // Optimistic UI update so the new set appears immediately on mobile even
      // if the session/user context briefly flickers.
      setSets((prev) => {
        const next = { ...prev };
        const list = next[exerciseId] ? [...next[exerciseId]] : [];
        list.push(data as any);
        next[exerciseId] = list;
        return next;
      });

      vibrate(15);
      setHighlightSetId((data as any).id);
      window.setTimeout(() => setHighlightSetId((prev) => (prev === (data as any).id ? null : prev)), 700);
      loadWorkout();
    }
  };


  const handleRepsKeyDown = (exerciseId: string, setIdx: number, e: any) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      focusByKey(`${exerciseId}:${setIdx}:weight`);
      return;
    }
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      focusByKey(`${exerciseId}:${setIdx + 1}:reps`);
      return;
    }
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      focusByKey(`${exerciseId}:${Math.max(0, setIdx - 1)}:reps`);
    }
  };

  const handleWeightKeyDown = async (
    exerciseId: string,
    setIdx: number,
    totalSets: number,
    e: any
  ) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      // Move to next set reps; if last set, create a new set and focus its reps
      if (setIdx + 1 < totalSets) {
        focusByKey(`${exerciseId}:${setIdx + 1}:reps`);
        return;
      }
      // create new set (keeps existing behavior; just adds a focus target)
      setPendingFocusKey(`${exerciseId}:${setIdx + 1}:reps`);
      vibrate(15);
      await addSet(exerciseId);
      return;
    }
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      focusByKey(`${exerciseId}:${setIdx + 1}:weight`);
      return;
    }
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      focusByKey(`${exerciseId}:${Math.max(0, setIdx - 1)}:weight`);
    }
  };


  const deleteSet = async (exerciseId: string, setId: string) => {
    // mark as removing for a subtle exit animation
    setRemovingSetIds((prev) => {
      const next = new Set(prev);
      next.add(setId);
      return next;
    });
    window.setTimeout(() => {
      setRemovingSetIds((prev) => {
        const next = new Set(prev);
        next.delete(setId);
        return next;
      });
    }, 800);
    await new Promise((r) => window.setTimeout(r, 140));
    vibrate([12, 8]);
    await supabase.from('workout_sets').delete().eq('id', setId);

    const remaining = (sets[exerciseId] || []).filter((s: any) => s.id !== setId);
    // Re-index remaining sets in a single request (avoids sequential UPDATE loop).
    const updates = remaining.map((s: any, i: number) => ({ id: s.id, set_index: i }));
    if (updates.length) {
      await supabase.from('workout_sets').upsert(updates, { onConflict: 'id' });
    }

    loadWorkout();
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="max-w-5xl mx-auto px-4 py-6">
		{/* Sticky session timer: stays visible while scrolling (HEVY-style) */}
        <div className="sticky top-0 z-40 -mx-4 px-4 pt-2 pb-3 backdrop-blur bg-background/70 border-b border-border">
          <div className="flex items-center justify-end">
            {/* No outline around the timer pill (smooth, like HEVY) */}
            <div className="inline-flex items-center gap-2 rounded-full bg-muted/70 px-3 py-1.5">
              <Clock className="h-4 w-4 text-foreground/90" />
              <span className="font-mono text-sm font-semibold tabular-nums">{formatClock(elapsedSeconds)}</span>
            </div>
          </div>
        </div>

        <div className="flex items-start justify-between gap-4 mb-6">
          <div className="min-w-0">
            <h1 className="text-2xl font-bold truncate">{session?.routines?.name || 'Workout'}</h1>
            {session?.routine_days?.name && <p className="text-muted-foreground truncate">{session.routine_days.name}</p>}
          </div>
        </div>

        {/* Rest timer is displayed inside each exercise card (HEVY style). */}

        {/* Exercise actions (3-dot menu) */}
<Sheet open={exerciseMenuOpen} onOpenChange={setExerciseMenuOpen}>
  <SheetContent side="bottom" className="rounded-t-2xl">
    <SheetHeader>
      <SheetTitle>Exercise Options</SheetTitle>
      <SheetDescription>Select an action.</SheetDescription>
    </SheetHeader>

    <div className="mt-4 space-y-2">
      <Button
        type="button"
        variant="ghost"
        className="w-full justify-start"
        onClick={() => exerciseMenuExerciseId && beginReplaceExercise(exerciseMenuExerciseId)}
      >
        <RefreshCcw className="h-4 w-4 mr-2" />
        Replace Exercise
      </Button>

      <Button
        type="button"
        variant="ghost"
        className="w-full justify-start text-red-500 hover:text-red-500"
        onClick={() => exerciseMenuExerciseId && removeExerciseFromSession(exerciseMenuExerciseId)}
      >
        <Trash2 className="h-4 w-4 mr-2" />
        Remove Exercise
      </Button>
    </div>
  </SheetContent>
</Sheet>

{/* Replace Exercise picker */}
<Sheet open={showReplaceExercise} onOpenChange={setShowReplaceExercise}>
  <SheetContent side="bottom" className="rounded-t-2xl">
    <SheetHeader>
      <SheetTitle>Replace Exercise</SheetTitle>
      <SheetDescription>Pick an exercise from your library.</SheetDescription>
    </SheetHeader>

    <div className="mt-4 space-y-3">
      <select
        value={replaceExerciseId}
        onChange={(e) => setReplaceExerciseId(e.target.value)}
        className="w-full h-11 rounded-xl border border-input bg-background bg-opacity-70 backdrop-blur px-3 text-sm text-foreground"
      >
        <option value="">Select Exercise</option>
        {availableExercises.map((ex) => (
          <option key={ex.id} value={ex.id}>
            {ex.name}
          </option>
        ))}
      </select>

      <Button
        type="button"
        className="w-full h-11 rounded-xl font-semibold"
        disabled={!replaceExerciseId}
        onClick={applyReplaceExercise}
      >
        Replace
      </Button>
    </div>
  </SheetContent>
</Sheet>

<div className="space-y-6">
          {exercises.map((exercise: any) => {
            const prevSets = prevSetsByExercise[exercise.id] || [];
            const isCardio = isCardioWorkoutExercise(exercise);
            // While reordering, collapse cards to just the exercise name for easier dragging (HEVY-like)
            const isReorderMode = Boolean(draggingExerciseId);

            return (
              <div
                key={exercise.id}
                ref={(el) => {
                  if (el) exerciseNodeRefs.current.set(exercise.id, el);
                  else exerciseNodeRefs.current.delete(exercise.id);
                }}
                className="bg-card border border-border rounded-2xl p-4 sm:p-5 shadow-sm relative"
                style={
                  draggingExerciseId === exercise.id
                    ? {
                        transform: `translateY(${dragTranslateY}px)`,
                        zIndex: 50,
                      }
                    : undefined
                }
              >
                {/* Exercise actions menu (HEVY-style) */}
                <button
                  type="button"
                  onClick={() => openExerciseMenu(exercise.id)}
                  disabled={sessionIsCompleted}
                  title={sessionIsCompleted ? 'Workout completed' : 'Exercise options'}
                  aria-label="Exercise options"
                  className="absolute top-3 right-3 inline-flex items-center justify-center rounded-lg p-1.5 text-muted-foreground hover:text-foreground disabled:opacity-40 disabled:pointer-events-none"
                >
                  <MoreVertical className="h-5 w-5" />
                </button>
                <div className="mb-3">
                  <div className="flex items-center gap-2">
                    {/* Drag handle (session-only reorder) */}
                    <button
                      type="button"
                      onPointerDown={(e) => startExerciseDrag(exercise.id, e)}
                      disabled={sessionIsCompleted}
                      aria-label="Reorder exercise"
                      title={sessionIsCompleted ? 'Workout completed' : 'Drag to reorder'}
                      className="inline-flex items-center justify-center rounded-lg p-1 text-muted-foreground hover:text-foreground disabled:opacity-40 disabled:pointer-events-none"
                      style={{ touchAction: 'none' }}
                    >
                      <GripVertical className="h-4 w-4" />
                    </button>

                    <h3 className="section-title text-foreground">{exercise.exercises?.name || 'Exercise'}</h3>
                  </div>

                  {!isReorderMode && !isCardio && (
                    <div className="mt-2 flex items-center justify-between gap-3">
                      {/* Technique on the left (no pill border) */}
                      <div className="min-w-0 flex items-center gap-2">
                        {/* Set technique (session + routine default) */}
                        <button
                          type="button"
                          onClick={() => openSetTechnique(exercise.id)}
                          disabled={sessionIsCompleted}
                          className="tap-target text-sm font-semibold text-primary truncate disabled:opacity-40 disabled:pointer-events-none"
                          aria-label="Change set technique"
                          title={sessionIsCompleted ? 'Workout completed' : 'Change set technique'}
                        >
                          {(Array.isArray(exercise.technique_tags) && exercise.technique_tags[0]) || 'Normal-Sets'}
                        </button>

                        {/* Technique instructions (for the currently selected technique) */}
                        <button
                          type="button"
                          onClick={() => openTechniqueGuide(exercise.id)}
                          className="tap-target inline-flex items-center justify-center rounded-lg p-1 text-foreground/70 hover:text-foreground"
                          aria-label="Technique instructions"
                          title="Technique instructions"
                        >
                          <Info className="h-4 w-4" />
                        </button>
</div>

                      {/* Rest timer on the right */}
                      <div className="flex items-center gap-2 text-sm text-muted-foreground shrink-0">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        {restSecondsRemaining !== null && restExerciseId === exercise.id ? (
                          <span className="font-medium">{formatClock(restSecondsRemaining)}</span>
                        ) : (
                          <span className="font-medium">{formatClock(getExerciseRestSeconds(exercise))}</span>
                        )}
                      </div>
                    </div>
                  )}
                </div>
                {!isReorderMode && (isCardio ? (() => {
                    const savedSecs = Number((exercise as any)?.duration_seconds || 0);
                    const draftValue = (cardioDraft[exercise.id] ?? '').toString();
                    const displayValue = draftValue !== '' ? draftValue : formatHMFromSeconds(savedSecs);
                    const parsedSecs = parseHM(displayValue);
                    const isDirty = draftValue.trim() !== '';
                    const isCompleted = savedSecs > 0 && !isDirty;
                    return (
                      <div className="mt-3 flex flex-col sm:flex-row sm:items-end gap-3">
                        <div className="flex-1">
                          <label className="block text-[11px] uppercase tracking-wide text-muted-foreground mb-1">
                            Duration (H:MM)
                          </label>
                          <input
                            type="text"
                            inputMode="numeric"
                            placeholder="0:25"
                            value={displayValue}
                            onChange={(e) => setCardioDraft((p) => ({ ...p, [exercise.id]: e.target.value }))}
                            disabled={sessionIsCompleted}
                            className="w-full h-11 px-3 rounded-xl border border-input bg-background text-center text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
                          />
                          {isCompleted ? (
                            <div className="mt-1 text-xs font-semibold text-emerald-300">Completed</div>
                          ) : null}
                        </div>

                        <button
                          type="button"
                          disabled={sessionIsCompleted || isCompleted}
                          onClick={async () => {
                            if (!parsedSecs || parsedSecs <= 0) {
                              alert('Cardio duration must be greater than 0.');
                              return;
                            }
                            const { error } = await supabase
                              .from('workout_exercises')
                              .update({ duration_seconds: parsedSecs })
                              .eq('id', exercise.id);

                            if (error) {
                              console.error(error);
                              alert(error.message || 'Failed to save duration.');
                              return;
                            }

                            setExercises((prev) =>
                              prev.map((ex) => (ex.id === exercise.id ? { ...ex, duration_seconds: parsedSecs } : ex))
                            );

                            setCardioDraft((p) => {
                              const copy = { ...p };
                              delete copy[exercise.id];
                              return copy;
                            });
                          }}
                          className="h-11 px-4 rounded-xl bg-primary text-primary-foreground font-semibold disabled:opacity-50 disabled:pointer-events-none"
                        >
                          {isCompleted ? 'Completed ✓' : 'Complete'}
                        </button>
                      </div>
                    );
                  })() : (
                  <div className="overflow-x-hidden">
  {/* HEVY-style header */}
  <div
    className="grid min-w-0 grid-cols-[32px_minmax(0,1fr)_78px_58px_32px] sm:grid-cols-[52px_minmax(0,1fr)_92px_76px_52px] gap-2 px-2 pb-2 text-left text-[11px] uppercase tracking-wide text-muted-foreground border-b border-border"
  >
    <div>Set</div>
    <div className="min-w-0">Previous</div>
    <div className="text-center">Weight</div>
    <div className="text-center">Reps</div>
    <div className="text-center">✓</div>
  </div>

  <div className="divide-y divide-border">
    {(sets[exercise.id] || []).map((set: any, idx: number) => {
      const prev = prevSets[idx];
      const prevReps = prev?.reps ?? null;
      const prevWeight = prev?.weight ?? null;

      const prevText =
        prevWeight !== null && prevWeight !== undefined && prevReps !== null && prevReps !== undefined
          ? `${prevWeight} lbs × ${prevReps}`
          : '-';

      const currentTechnique =
        (Array.isArray(exercise.technique_tags) && exercise.technique_tags[0]) || 'Normal-Sets';
      const isLastSetForExercise =
        idx === Math.max(0, (sets[exercise.id] || []).length - 1) && (sets[exercise.id] || []).length > 0;
      const showTechniqueReminder =
        isLastSetForExercise && TECHNIQUE_LAST_SET_REMINDER.has(currentTechnique);

      const weightPlaceholder =
        prevWeight !== null && prevWeight !== undefined && prevWeight !== '' ? String(prevWeight) : '';
      const repsPlaceholder =
        prevReps !== null && prevReps !== undefined && prevReps !== '' ? String(prevReps) : '';

      const swipeOffset = swipeOffsetBySetId[set.id] ?? 0;

      return (
        <Fragment key={set.id}>
          {showTechniqueReminder ? (
            <div className="px-2 pt-3 pb-2">
              <div className="flex items-center justify-center text-xs font-semibold text-primary">
                <Dumbbell className="h-4 w-4 mr-2" />
                <span>Technique Required: {currentTechnique.toUpperCase()}</span>
                <Dumbbell className="h-4 w-4 ml-2" />
              </div>
            </div>
          ) : null}

          {/* Swipe-to-delete row (HEVY-style) */}
          <div className="relative">
            {/* Delete action background */}
            <button
              type="button"
              onClick={() => deleteSet(exercise.id, set.id)}
              className="absolute inset-y-0 right-0 w-[120px] bg-red-500 text-white font-semibold flex items-center justify-center gap-2"
              aria-label="Delete set"
            >
              <Trash2 className="h-4 w-4" />
              Delete
            </button>

            {/* Foreground content that slides */}
            <div
              className={
                "grid min-w-0 grid-cols-[32px_minmax(0,1fr)_78px_58px_32px] sm:grid-cols-[52px_minmax(0,1fr)_92px_76px_52px] gap-2 items-center px-2 py-2 bg-card touch-pan-y"
              }
              style={{ transform: `translateX(${swipeOffset}px)`, transition: swipeDraggingSetId === set.id ? 'none' : 'transform 150ms ease' }}
              onTouchStart={(e) => onSetSwipeStart(set.id, e)}
              onTouchMove={(e) => onSetSwipeMove(set.id, e)}
              onTouchEnd={(e) => onSetSwipeEnd(set.id, e)}
              onTouchCancel={(e) => onSetSwipeEnd(set.id, e)}
            >
              {/* SET # */}
              <div className="font-semibold text-muted-foreground tabular-nums">{idx + 1}</div>

              {/* PREVIOUS */}
              <div
                className="min-w-0 text-[11px] sm:text-sm text-foreground/90 leading-tight truncate whitespace-nowrap"
                title={prevText}
              >
                {prevText}
              </div>

              {/* WEIGHT */}
              <div>
                <input
                  type="number"
                  inputMode="decimal"
                  aria-label={`Weight for set ${idx + 1}`}
                  step="0.5"
                  placeholder={weightPlaceholder}
                  value={getDisplayValue(set.id, 'weight', set.weight)}
                  onChange={(e) => {
                    const v = e.target.value;
                    setDraftValue(set.id, 'weight', v);
                    scheduleDraftSave(set.id, 'weight', v);
                  }}
                  onFocus={(e) => e.currentTarget.select()}
                  ref={(el) => {
                    const keyA = `${exercise.id}:${set.id}:weight`;
                    const keyB = `${exercise.id}:${idx}:weight`;
                    if (el) {
                      inputRefs.current.set(keyA, el);
                      inputRefs.current.set(keyB, el);
                    } else {
                      inputRefs.current.delete(keyA);
                      inputRefs.current.delete(keyB);
                    }
                  }}
                  onKeyDown={(e) => handleWeightKeyDown(exercise.id, idx, (sets[exercise.id] || []).length, e)}
                  onBlur={() => {
                    const raw = getDraftRaw(set.id, 'weight').trim();
                    const num = raw === '' ? 0 : Number(raw);
                    saveSet(set.id, 'weight', Number.isFinite(num) ? num : 0);
                    clearDraftField(set.id, 'weight');
                  }}
                  className="w-full h-10 sm:h-11 px-1 sm:px-2 py-2 rounded-xl border border-input bg-background text-center text-sm sm:text-base text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
                />
              </div>

              {/* REPS */}
              <div>
                <input
                  type="number"
                  inputMode="numeric"
                  aria-label={`Reps for set ${idx + 1}`}
                  placeholder={repsPlaceholder}
                  value={getDisplayValue(set.id, 'reps', set.reps)}
                  onChange={(e) => {
                    const v = e.target.value;
                    setDraftValue(set.id, 'reps', v);
                    scheduleDraftSave(set.id, 'reps', v);
                  }}
                  onFocus={(e) => e.currentTarget.select()}
                  ref={(el) => {
                    const keyA = `${exercise.id}:${set.id}:reps`;
                    const keyB = `${exercise.id}:${idx}:reps`;
                    if (el) {
                      inputRefs.current.set(keyA, el);
                      inputRefs.current.set(keyB, el);
                    } else {
                      inputRefs.current.delete(keyA);
                      inputRefs.current.delete(keyB);
                    }
                  }}
                  onKeyDown={(e) => handleRepsKeyDown(exercise.id, idx, e)}
                  onBlur={() => {
                    const raw = getDraftRaw(set.id, 'reps').trim();
                    const num = raw === '' ? 0 : Number(raw);
                    saveSet(set.id, 'reps', Number.isFinite(num) ? num : 0);
                    clearDraftField(set.id, 'reps');
                  }}
                  className="w-full h-10 sm:h-11 px-1 sm:px-2 py-2 rounded-xl border border-input bg-background text-center text-sm sm:text-base text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
                />
              </div>

              {/* DONE */}
              <div className="flex justify-center">
                <button
                  type="button"
                  onClick={() => handleToggleCompleted(exercise, set)}
                  className={`w-8 h-8 sm:w-11 sm:h-11 rounded border-2 flex items-center justify-center ${
                    set.is_completed ? 'bg-primary border-primary text-primary-foreground' : 'border-input'
                  }`}
                  title="Mark set complete"
                >
                  {set.is_completed && <span className="text-xs">✓</span>}
                </button>
              </div>
            </div>
          </div>
        </Fragment>
      );
    })}
  </div>

                  {/* Add set button (HEVY-style pill) */}
                  <div className="mt-3">
                    <button
                      type="button"
                      aria-label="Add set"
                      onClick={() => addSet(exercise.id)}
                      className="w-full h-14 rounded-2xl bg-muted border border-input text-foreground text-base font-semibold inline-flex items-center justify-center gap-2 active:scale-[0.99]"
                    >
                      <Plus className="h-5 w-5" aria-hidden="true" />
                      Add Set
                    </button>
                  </div>
                </div>
                ))}
              </div>
            );
          })}

          <div className="pt-6 space-y-3">
            {showAddExercise ? (
              <div className="surface p-4">
                <select
                  value={selectedExerciseId}
                  onChange={(e) => setSelectedExerciseId(e.target.value)}
                  className="w-full h-11 rounded-xl border border-input bg-background bg-opacity-70 backdrop-blur px-3 text-sm text-foreground mb-3"
                >
                  <option value="">Select Exercise</option>
                  {availableExercises.map((ex) => (
                    <option key={ex.id} value={ex.id}>
                      {ex.name}
                    </option>
                  ))}
                </select>

                <div className="flex gap-2">
                  <Button
                    onClick={addExerciseToSession}
                    disabled={addingExercise}
                    className="flex-1"
                  >
                    {addingExercise ? 'Adding…' : 'Add'}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setShowAddExercise(false);
                      setSelectedExerciseId('');
                    }}
                    disabled={addingExercise}
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            ) : (
              <Button
                variant="outline"
                onClick={() => setShowAddExercise(true)}
                className="w-full gap-2"
              >
                <Plus className="w-4 h-4" />
                <span>Add Exercise</span>
              </Button>
            )}

            <button
              onClick={endWorkout}
              disabled={ending || discarding}
              className="tap-target w-full min-h-[48px] px-4 py-3 rounded-2xl bg-primary text-primary-foreground font-semibold shadow-sm transition hover:shadow-md active:translate-y-px disabled:opacity-60 disabled:cursor-not-allowed"
            >
              {ending ? 'Ending…' : 'End Workout'}
            </button>

            <button
              onClick={discardWorkout}
              disabled={ending || discarding}
              className="tap-target w-full min-h-[48px] px-4 py-3 rounded-2xl border border-destructive/60 text-destructive font-semibold bg-transparent transition hover:bg-red-500/10 disabled:opacity-60 disabled:cursor-not-allowed"
            >
              {discarding ? 'Discarding…' : 'Discard Workout'}
            </button>
          </div>

          {exercises.length === 0 && <div className="text-muted-foreground">No exercises found for this session.</div>}
        </div>
      </div>

{/* Set-technique picker (persist to session; and to routine template when applicable) */}
<Sheet open={setTechniqueOpen} onOpenChange={setSetTechniqueOpen}>
  <SheetContent
    side="bottom"
    className="border-t border-border bg-background text-foreground shadow-2xl"
  >
    <div className="space-y-4">
      <SheetHeader>
        <SheetTitle className="text-foreground">Set Technique</SheetTitle>
        <SheetDescription className="text-muted-foreground">
          This updates the current workout in real time. If this workout was started from a routine day, it also becomes
          the default for future workouts until you change it again.
        </SheetDescription>
      </SheetHeader>

      <div className="grid grid-cols-2 gap-2">
        {SET_TECHNIQUES.map((t) => (
          <button
            key={t}
            type="button"
            onClick={() => applySetTechnique(t)}
            className="rounded-xl border border-border bg-card px-3 py-2 text-left text-sm font-semibold text-foreground hover:bg-muted"
          >
            {t}
          </button>
        ))}
      </div>
    </div>
  </SheetContent>
</Sheet>

<Sheet open={techniqueGuideOpen} onOpenChange={(open) => {
  setTechniqueGuideOpen(open);
  if (!open) setTechniqueGuideExerciseId(null);
}}>
  <SheetContent
    side="bottom"
    className="border-t border-border bg-background text-foreground shadow-2xl"
  >
    {(() => {
      const ex = techniqueGuideExerciseId
        ? exercises.find((e: any) => e.id === techniqueGuideExerciseId)
        : null;
      const key =
        (ex && Array.isArray((ex as any).technique_tags) && (ex as any).technique_tags[0]) || 'Normal-Sets';
      const guide = TECHNIQUE_GUIDES[key] || TECHNIQUE_GUIDES['Normal-Sets'];
      if (!guide) return null;
      return (
        <div className="space-y-4">
          <SheetHeader>
            <SheetTitle className="text-foreground">{guide.title}</SheetTitle>
            <SheetDescription className="text-muted-foreground">{guide.summary}</SheetDescription>
          </SheetHeader>

          <div className="space-y-3">
            <div>
              <div className="mb-2 text-sm font-semibold text-foreground">How To</div>
              <ol className="list-decimal space-y-2 pl-5 text-sm text-foreground/90">
                {guide.steps.map((s) => (
                  <li key={s}>{s}</li>
                ))}
              </ol>
            </div>

            {guide.tips?.length ? (
              <div>
                <div className="mb-2 text-sm font-semibold text-foreground">Tips</div>
                <ul className="list-disc space-y-2 pl-5 text-sm text-foreground/90">
                  {guide.tips.map((t) => (
                    <li key={t}>{t}</li>
                  ))}
                </ul>
              </div>
            ) : null}
          </div>
        </div>
      );
    })()}
  </SheetContent>
</Sheet>
</div>
  );
}